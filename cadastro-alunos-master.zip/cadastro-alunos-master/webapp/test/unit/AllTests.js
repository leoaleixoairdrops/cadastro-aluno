sap.ui.define([
	"ovly/fiori_10/cadastro_de_alunos/test/unit/controller/Lista.controller"
], function () {
	"use strict";
});